import pymysql
import logging
import json

endpoint = 'onlinemuseum.cnbwnikf8zfu.us-east-1.rds.amazonaws.com'
username = 'onlinemuseum'
password = '12345678'
database_name = 'Online_Museum'

connection = pymysql.connect(endpoint, user=username,
                             passwd=password, db=database_name)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
logger.setLevel(level=logging.INFO)


def lambda_handler(event, context):
    cursor = connection.cursor()
    cursor.excute('SELECT * FROM Img WHERE FAV = 1')

    rows = cursor.fetchall()

    logger.info(event)
    body = event['body']

    logger.info(body)
    body = json.loads(body)
    logger.info(body)
    address = body.get('address', None)
    logger.info(body['address'])

    logger.info(address)

    return {
        'statusCode': 200,
        'body': json.dumps('Get favorite!')
    }
